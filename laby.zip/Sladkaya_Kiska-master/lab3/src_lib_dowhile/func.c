#include <math.h>

double a(int i)
{
	return pow(-1, i)*(i + 1.0) / (pow(i, 2) + 1.0);
}