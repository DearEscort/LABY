#pragma once
#include <math.h>
#include <stdio.h>

double a(int i);
double summ(int n);
double summ2(double eps);
void print(int n, int k);
int findFirstElement(double eps);
int findFirstNegativeElement(double eps);