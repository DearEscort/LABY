#pragma once
#include <math.h>
#include <stdio.h>

void readArray(int *arr, int n);
void sort(int *arr, int n);
void sortStackArray();
void writeArray(int *arr, int n);