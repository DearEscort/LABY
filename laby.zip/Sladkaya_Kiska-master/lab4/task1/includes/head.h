#pragma once
#include <math.h>
#include <stdio.h>

void f(const double *x, double *result);