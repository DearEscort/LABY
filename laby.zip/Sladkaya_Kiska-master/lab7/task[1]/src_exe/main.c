#include <head.h> 

void main(void)
{
	incrementHeapVariable();
	system("pause");
}