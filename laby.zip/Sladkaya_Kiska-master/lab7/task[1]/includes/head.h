#include <stdio.h>
#include <stdlib.h>

void incrementHeapVariable(void);