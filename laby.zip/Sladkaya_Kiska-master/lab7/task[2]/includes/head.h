#pragma once
#include <stdio.h>
#include <stdlib.h>

void sortHeapArray();
void sort(int *arr, int n);
void readArray(int *arr, int n);
void writeArray(int *arr, int n);