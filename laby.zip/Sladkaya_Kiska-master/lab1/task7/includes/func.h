#pragma once
#include <stdio.h>

extern double x;
extern double result;
void f(void);