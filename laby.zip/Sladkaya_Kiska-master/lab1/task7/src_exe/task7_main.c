#include <func.h>

void main(int argc, char *argv[])
{
	f();
	printf("x=%.4lf\n", x);
	printf("f(x)= %.4lf\nx=", result);
	scanf_s("%lf", &x);
	f();
	printf("f(x)= %.4lf\n", result);
	system("pause");
}