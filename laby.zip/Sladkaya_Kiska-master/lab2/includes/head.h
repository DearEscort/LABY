#pragma once
#include <stdio.h>
#include <math.h>

_Bool isInArea(double x, double y);
double f(double x);